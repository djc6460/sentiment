# Sentiment System

This system for the in development ttrpg sentiment. It is currently bare bones.

## Current todo list
Add popups for all rolls to add bonus dice and modifiers.  
Add/Steal a status system to put icons over tokens.  
